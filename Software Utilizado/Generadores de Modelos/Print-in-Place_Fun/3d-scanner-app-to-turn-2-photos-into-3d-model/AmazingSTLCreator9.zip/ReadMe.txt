1. Unzip the app to any folder (for example D:\Amazing\ )
2. Launch the app
3. The app places resulting file Amazing.stl to the same folder where the app is located.