Thank you for purchasing the application "Amazing STL Creator 13: Jewelry"!

Easy installation and use:
1. Unzip the app to any folder (for example D:\Amazing\ )
2. Launch the app
3. If a Windows warning appears like "Windows protected your PC", please click “More info” and “Run anyway”
4. The app places resulting file Amazing.stl to the same folder where the app is located.

Just load the JPG and choose what to create (pendant, earring, bracelet, signet ring, bas-relief ring).

STLs created for the most typical settings of FDM printers: no supports, layer height 0.2 mm, nozzle 0.4 mm, print speed 40-60 mm/s, PLA plastic, 0 % infill.

Please write me if any question
posmetyen@yahoo.com




